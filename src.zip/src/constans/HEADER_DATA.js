export const HEADER_DATA = {
    connectionList: [
        {
            title: 'Request a Sample',
            id: 'Request a Sample',
        },
        {
            title: 'Help',
            id: 'Help',
        },
        {
            title: 'Contact',
            id: 'Contact',
        },
    ],
    navigationList: [
        {
            title: 'Products',
            id: 'Products',
        },
        {
            title: 'Resources',
            id: 'Resources',
        },
        {
            title: 'Services',
            id: 'Services',
        },
        {
            title: 'Locations',
            id: 'Locations',
        },
        {
            title: 'Careers',
            id: 'Careers',
        },
        {
            title: 'Support',
            id: 'Support',
        },
    ],
}