export { default as BannerSlider } from './BannerSlider'
