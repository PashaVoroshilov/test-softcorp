export { default as Advantages } from './Advantages'
